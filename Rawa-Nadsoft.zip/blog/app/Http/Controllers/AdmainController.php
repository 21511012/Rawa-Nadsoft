<?php

namespace App\Http\Controllers;
use Illuminate\Support\Facades\DB;

use Illuminate\Http\Request;

class AdmainController extends Controller
{public function backend(){

    $post3=DB::table('social-solidarity')
    ->select('*')
    ->get();
    $post2=DB::table('information-pay')
    ->select('*')
    ->get();
    $post1=DB::table('information-founding')
    ->select('*')
    ->get();
    
    return view('admain',compact('post3','post2','post1'));
}
}
