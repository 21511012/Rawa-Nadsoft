<html lang="rtl">
    <head>
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/js/bootstrap.bundle.min.js" integrity="sha384-b5kHyXgcpbZJO/tY9Ul7kGkf1S0CWuKcCD38l8YkeH8z8QjE0GmW1gYU5S9FOnJ0" crossorigin="anonymous"></script>
        <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.6.0/dist/umd/popper.min.js" integrity="sha384-KsvD1yqQ1/1+IA7gi3P0tyJcT3vR+NdBTt13hSJ2lnve8agRGXTTyNaBYmCR/Nwi" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/js/bootstrap.min.js" integrity="sha384-nsg8ua9HAw1y0W1btsyWgBklPnCUAFLuTMS2G72MMONqmOymq585AcH49TLBQObG" crossorigin="anonymous"></script>
   
   <style>
   h1{
    float: right!important;
    color: #5B79CA;
   }
   </style>
</head>
    <body dir="rtl" style="margin:20px;">
    
   
    <section style="margin-top: 10px;">
    <h1> معلومات التبرع</h1>
       <table class="table">
       <thead class="thead-light">
    <tr>
     
    <th scope="col">personal information</th>   
      <th scope="col">نوع التبرع</th>
      <th scope="col">العملة</th>
      <th scope="col">المبلغ </th>
      <th scope="col"> الاسم: </th>
      <th scope="col"> المدينة: </th>
      <th scope="col">الهاتف</th>
      <th scope="col">البريد الالكتروني: </th>
      <th scope="col">البلد </th>
      <th scope="col">العنوان: </th>
      <th scope="col">(forign-key)رقم المستخدم الدفع</th>

    </tr>
  </thead>

  <tbody>
  @foreach($post1 as  $key => $post )

    <tr>
      <th scope="row">{{$post->id}}</th>
      <td>{{$post->pay_way}}</td>
      <td>{{$post->coin}}</td>
      <td>{{$post->amount_founded}}</td>
      <td>{{$post->name}}</td>
      <td>{{$post->city}}</td>
      <td>{{$post->phone}}</td>
      <td>{{$post->email}}</td>
      <td>{{$post->town}}</td>
      <td>{{$post->address}}</td>
      <td>{{$post->id_fk}}</td>

      
    </tr>
   
    @endforeach

  </tbody>
</table>
</section>
<section style="margin-top: 10px;">
<h1>المعلومات الشخصية</h1>
<table class="table">
<thead class="thead-light">
    <tr>
     
    <th scope="col">pay information</th>   
      <th scope="col"> طريقة الدفع </th>
      <th scope="col">اسم حامل البطاقة:</th>
      <th scope="col">تاريخ انتهاء البطاقة: </th>
      <th scope="col">رقم البطاقة:  </th>
      <th scope="col">cvc </th>
     


    </tr>
  </thead>

  <tbody>
  @foreach($post2 as  $key => $post )

    <tr>
      <th scope="row">{{$post->id}}</th>
      <td>{{$post->type_coin}}</td>
      <td>{{$post->name}}</td>
      <td>{{$post->dates}}</td>
      <td>{{$post->card_number}}</td>
      <td>{{$post->cvc}}</td>

    </tr>
   
    @endforeach

  </tbody>
</table>
</section>
 
        
<section style="margin-top: 10px;">
<h1> قائمة النشر </h1>
       <table class="table">
       <thead class="thead-light">
    <tr>
     
    <th scope="col">list</th>   
      <th scope="col">الاسم </th>
      <th scope="col">البريد الالكتروني</th>
      
    </tr>
  </thead>

  <tbody>
  @foreach($post3 as  $key => $post )

    <tr>
      <th scope="row">{{$post->id}}</th>
      <td>{{$post->name}}</td>
      <td>{{$post->email}}</td>
     

      
    </tr>
   
    @endforeach

  </tbody>
</table>
</section>
     
</body>
</html>