$(".sendjoin").click(function(stay){
    stay.preventDefault()

    var formData = new FormData($('form')[0]);
    console.log(formData)

     

      $.ajax({
          type: 'POST',
          url: "{{ url('/sendjoin') }}",
          data:formData,
          processData: false,
          contentType: false, // here $(this) refers to the ajax object not form
          headers: {
              'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
          },
          success: function (data) {
             console.log(data)
          },
      });

    
});